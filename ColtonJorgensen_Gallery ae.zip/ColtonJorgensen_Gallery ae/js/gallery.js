
 
var request = new XMLHttpRequest();
 

 
request.open('Get', 'https://csjorgensen.github.io/ColtonJorgensen_ProjectAndPortfolioIII/ColtonJorgensen_Gallery/imgGalleryPhotos.json',true);
 
