var imgGallery = new XMLHttpRequest();

var iGal = new XMLHttpRequest();	
iGal.onload = function(){
	
var data = JSON.parse(iGal.responseText);
	
	var imagePlace = document.querySelector('#gallery');
	if(imagePlace){
		var imgGal = '';
		for (var i= 0; i<data.imgGal.length;i++){
			imgGal += '<article>';
			imgGal += '<p><img src="' + data.imgGal[i].imageFile+'"alt"' +data.imgGal[i].imageFile+'"></p>';
			imgGal += '<h3 class="h3">'+data.imgGal[i].imgName+'</h3>';
			
			imgGal += '<p>'+data.imgGal[i].description+'</p>';
			imgGal += '</article>';	
		}
		 imagePlace.querySelector('h2').insertAdjacentHTML('afterend', imagePlace);
	}


function slideImage(event){
	var imgGal = event.target.src;
	var parent = event.target.parentElement;
	var bigImage = document.querySelector('#gallery img');
	
	
	bigImage.src = imgGal;
	
	document.querySelector("#gallery.active").classList.remove("active");
	parent.className = 'active';


function slideImage(event){

	var bigImage = document.querySelector('#gallery img');
	
	
	var bigImage;
	document.querySelectorAll('pagination ul');
	var activeIndex;
	var activeListItem;
	for (var i=0; i<bigImage.length; i++){
		if(bigImage[i].imageName=='active'){
			activeIndex = i;
			activeListItem = i + 1;
			
		}}
	
	
		if (activeIndex >=1){
			
			var nextIndex  = 5;
			var nextListItem = 6;
		}else{var nextIndex = activeIndex-1;
			  var nextListItem = activeListItem -1;
		}
	}}
	



// Change via Next Button
function nextImage(event) {
	
	// Find Current Image
	var bigImage = document.querySelectorAll('#gallery');
	var activeIndex; // js (starts /w 0)
	var activeListItem; // css (starts /w 1)
	for (var i=0; i < bigImage.length; i++) {
		if (bigImage[i].className == 'active') {
			activeIndex = i;
			activeListItem = i - 1;
		}
	}
	
	// Determine Next Image
	if (activeIndex >= 5) {
		var nextIndex = 1;
		var nextListItem = 2; 
	} else {
		var nextIndex = activeIndex + 1;
		var nextListItem = activeListItem + 1;		
	}
	
	 // Change Large Image
	var imgGal = document.querySelector('.pagination li:last-of-type button (' + nextListItem + ') img').src;
	var bigImage = document.querySelector('#gallery img');
	bigImage.src = imgGal;
	
	// Change active indicator
	document.querySelector("#gallery .active").classList.remove("active");
	var parent = document.querySelector('.pagination li:last-of-type button (' + nextListItem + ')');
	parent.className = 'active';
	
}


// Change via Previous Button
// Change via Previous Button
function previousImage(event) {
	
	// Find Current Image
	var bigImage = document.querySelectorAll('#gallery');
	var activeIndex; // js (starts /w 0)
	var activeListItem; // css (starts /w 1)
	for (var i=0; i < bigImage.length; i++) {
		if (bigImage[i].className == 'active') {
			activeIndex = i;
			activeListItem = i + 1;
		}
	}
	
	// Determine Pevious Image
	if (activeIndex <= 1) {
		var previousIndex = 5;
		var previousListItem = 6;
	} else {
		var previousIndex = activeIndex - 1;
		var previousListItem = activeListItem - 1;		
	}
	
	// Change Large Image
	var imgGal = document.querySelector('.pagination li:first-of-type button(' + previousListItem + ') img').src;
	var bigImage = document.querySelector('#gallery img');
	bigImage.src = imgGal;
	
	// Change active indicator
	document.querySelector("#gallery .active").classList.remove("active");
	var parent = document.querySelector('.pagination li:first-of-type button(' + previousListItem + ')');
	parent.className = 'active';
	
}


var next = document.querySelector('.pagination li:last-of-type button');
next.addEventListener("click", nextImage);

var previous = document.querySelector('.pagination li:first-of-type button');
previous.addEventListener("click", previousImage);
}

iGal.open('GET', 'https://csjorgensen.github.io/ColtonJorgensen_ProjectAndPortfolioIII/ColtonJorgensen_Gallery/imgGalleryPhotos.json',true);
iGal.send(null);
